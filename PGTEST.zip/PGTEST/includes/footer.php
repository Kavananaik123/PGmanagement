<?php
  //PHP variable storing property list page path
  $property_list_path = "/PGLIFE/property_list.php";
?>

<!-- Footer Section -->
<div class="footer">
    <div class="page-container footer-container">
        <div class="footer-cities">
            <div class="footer-city">
                <a href="<?php echo $property_list_path.'?city=Nitte'; ?>">PG in Nitte</a>
            </div>
            <div class="footer-city">
                <a href="<?php echo $property_list_path.'?city=Mumbai'; ?>">PG in Karkala</a>
            </div>
            <div class="footer-city">
                <a href="<?php echo $property_list_path.'?city=Bengaluru'; ?>">PG in Belmann</a>
            </div>
            <div class="footer-city">
                <a href="<?php echo $property_list_path.'?city=Hyderabad'; ?>">PG in Padubidri</a>
            </div>
        </div>
        <div class="footer-copyright">© 2022 Copyright PG Life </div>
    </div>
</div>
